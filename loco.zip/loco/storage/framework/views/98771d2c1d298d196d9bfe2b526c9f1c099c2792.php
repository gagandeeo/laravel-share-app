<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/register.css')); ?>" />
</head>
<body>
    <div class="register__container">
            <form action=" <?php echo e(route('components.save')); ?> " class="register__form" method='post'>

                <?php if(Session::get('success')): ?>
                    <span class="alert__reg">
                        <?php echo e(Session::get('success')); ?>

                    </span>
                <?php endif; ?>

                <?php if(Session::get('fail')): ?>
                    <span class="alert__reg">
                        <?php echo e(Session::get('fail')); ?>

                    </span>
                <?php endif; ?>

                <?php echo csrf_field(); ?>

                <div class="row">
                    <span class="alert"> <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                    <input type="text" name='name' value="<?php echo e(old('name')); ?>" placeholder='Enter username'>
                </div>
                <div class="row">
                    <span class="alert"> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                    <input type="text" name='email' value="<?php echo e(old('email')); ?>" placeholder='Enter Email Address'>
                </div>
                <div class="row">
                    <span class="alert"> <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                    <input type="password" name='password' placeholder='Enter password'>                   
                </div>
                    <button class="register__button" type="submit">Signup</button>
                <a href="<?php echo e(route('components.login')); ?>">Already have an account? Login</a>
            </form>                
    </div>
</body>
</html><?php /**PATH /home/gdpvirus/Desktop/sem6/WE/lab/assignment5/loco/resources/views/components/register.blade.php ENDPATH**/ ?>