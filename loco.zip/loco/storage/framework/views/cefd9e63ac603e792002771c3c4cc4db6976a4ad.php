<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>" />
        <title>Dashboard</title>
    </head>
    <body >
            <?php if($message = Session::get('Success')): ?>
            <div class="alert__success">
                <strong><?php echo e($message); ?></strong>
            </div>
          <?php endif; ?>
          <?php if($message = Session::get('alert')): ?>
            <div class="alert__danger">
                <strong><?php echo e($message); ?></strong>
            </div>
          <?php endif; ?>
          <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>
          <div style="margin-top:20px">
            <a class="sharelink__ref" href="<?php echo e(route('post.uploadFile')); ?>">Share File</a>
        </div>
            <div class="list__container">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post__container">
                    <h4 class="post__title">
                        <?php echo e($values->title); ?>      
                    </h4>
                    <image src="<?php echo e($values->path); ?>" class="post__image" alt="Data File" width="300px" height="300px"/>
                    <div class="info__field">
                        <h4>Description: <?php echo e($values->description); ?></h4>
                    </div>
                    <a class="link__ref" href="/post/download/<?php echo e($values->id); ?>">Download</a> 
                    <a class="edit__ref" href="/post/user-post/update/<?php echo e($values->id); ?>">Edit</a> 
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    </body>
</html><?php /**PATH /home/gdpvirus/Desktop/sem6/WE/lab/assignment5/loco/resources/views/components/user-post.blade.php ENDPATH**/ ?>