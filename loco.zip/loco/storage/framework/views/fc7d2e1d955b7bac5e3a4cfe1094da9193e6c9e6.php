<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>" />
    <title>Dashboard</title>
</head>
<body>
    <div class="dashboard__container">
        <div class="header">
                <img  class="header__logo" src="<?php echo e(asset('widgets/logor.png')); ?>" alt="" width="100" height="100">
                <div class="header__right">
                    <div class="dropdown">
                        <span>Profile</span>
                        <div class="dropdown-content">
                            <h4>Username:</h4>
                            <h4>Description:</h4>
                        </div>
                    </div>  
                    <a href="<?php echo e(route('components.logout')); ?>">LogOut</a>
                </div>
        </div>
            <a class="sharelink__ref" href="<?php echo e(route('post.uploadFile')); ?>">Share File</a> 
            <a class="sharelink__ref" href="<?php echo e(route('post.getUserPost')); ?>">My Uploads</a> 
        <div class="list__container">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="post__container">
                <h4 class="post__title">
                    <?php echo e($values->title); ?>      
                </h4>
                <image src="<?php echo e($values->path); ?>" class="post__image" alt="Data File" width="300px" height="300px"/>
                <div class="info__field">
                    <h4>Description: <?php echo e($values->description); ?></h4>
                </div>
                 <a class="link__ref" href="/post/download/<?php echo e($values->id); ?>">Download</a> 
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</body>
</html>

<?php /**PATH /home/gdpvirus/Desktop/sem6/WE/lab/assignment5/loco/resources/views/components/dashboard.blade.php ENDPATH**/ ?>