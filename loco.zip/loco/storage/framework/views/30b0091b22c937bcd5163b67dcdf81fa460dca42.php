<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>" />
    <title>Login</title>
</head>
<body>
    <div class="login__container">
            <form action=" <?php echo e(route('components.check')); ?> " class="login__form" method='post'>
                    <?php echo csrf_field(); ?>
                    <?php if(Session::get('success')): ?>
                        <?php echo e(Session::get('success')); ?>

                    <?php endif; ?>
                    <?php if(Session::get('fail')): ?>
                        <?php echo e(Session::get('fail')); ?>

                    <?php endif; ?>
                    <div class="row">
                        <span class="alert"> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                        <input type="text" name='email' value="<?php echo e(old('email')); ?>" placeholder='Enter Email Address'>
                    </div>
                    <div class="row">
                        <span class="alert">         
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                        <input type="password" name='password' placeholder='Enter password'>
                    </div>
                        <button class="login__button" type="submit">Login</button>
                <a  href="<?php echo e(route('components.register')); ?>">Signup?</a>
            </form>                
    </div>
</body>
</html><?php /**PATH /home/gdpvirus/Desktop/sem6/WE/lab/assignment5/loco/resources/views/components/login.blade.php ENDPATH**/ ?>